package edu.wit.caresync;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import edu.wit.caresync.api.Cookies;
import edu.wit.caresync.ui.ComponentManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.Cookie;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
/*

public class MainActivity2 extends AppCompatActivity {

    private final ComponentManager componentManager = new ComponentManager();
    private final String BASE_URL = "https://caresync.na-stewart.com/api/v1/";
    private OkHttpClient httpClient;
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private SharedPreferences sharedPreferences;

    private TextView stepsValue;
    private TextView heartRateValue;
    private TextView waterIntakeValue;
    private TextView caloriesBurnedValue;
    private TextView activeTimeValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharedPreferences = getApplicationContext().getSharedPreferences("CookiePrefs", Context.MODE_PRIVATE);

        stepsValue = findViewById(R.id.stepsValue);
        heartRateValue = findViewById(R.id.heartRateValue);
        waterIntakeValue = findViewById(R.id.waterIntakeValue);
        caloriesBurnedValue = findViewById(R.id.caloriesBurnedValue);
        activeTimeValue = findViewById(R.id.activeTimeValue);
        httpClient = new OkHttpClient.Builder().cookieJar(new Cookies(sharedPreferences)).build();
        addContainersToManager();
    }

    private void addContainersToManager() {
        componentManager.addComponent("init", findViewById(R.id.initContainer));
        componentManager.addComponent("login", findViewById(R.id.oAuthContainer));
        componentManager.addComponent("dashboard", findViewById(R.id.dashboardContainer));
        componentManager.addComponent("healthDashboard", findViewById(R.id.healthDashboardContainer));
    }

    public void login(View view) {
        componentManager.switchView("login");

        final WebView webView = findViewById(R.id.oAuthWebView);
        CookieManager cookieManager = CookieManager.getInstance();
        webView.clearCache(true);
        cookieManager.removeAllCookies(null);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (url.contains("/callback")) {
                    HttpUrl httpUrl = HttpUrl.parse(url);
                    httpClient.cookieJar().saveFromResponse(httpUrl,
                            List.of(Cookie.parse(httpUrl, cookieManager.getCookie(url).trim())));
                    runOnUiThread(() -> componentManager.switchView("dashboard"));
                }
            }
        });
        webView.loadUrl(BASE_URL + "security/login");
    }



    public void showHealthDashboard(View view) {
        componentManager.switchView("healthDashboard");
        loadWeeklyActivities();
        loadAllWeeklyStats();
    }

    private void loadAllWeeklyStats() {
        loadWeeklyStats(stepsValue, "steps");
        loadWeeklyStats(heartRateValue, "heart");
        loadWeeklyStats(waterIntakeValue, "water");
        loadWeeklyStats(caloriesBurnedValue, "calories");
        loadWeeklyStats(activeTimeValue, "active");
    }

    public void loadWeeklyActivities() {
        LocalDate endDate = LocalDate.now();
        LocalDate startDate = endDate.minusDays(7);

        final String urlStr = String.format("%sfitbit/activity/list/weekly?startDate=%s&endDate=%s",
                BASE_URL,
                startDate.format(dateFormatter),
                endDate.format(dateFormatter));

        final LinearLayout recentContainer = findViewById(R.id.recentActivitiesContainers);
        recentContainer.removeAllViews();

        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try (Response response = httpClient.newCall(new Request.Builder().url(urlStr).build()).execute()) {
                if (response.code() == 200) {
                    JSONObject json = new JSONObject(response.body().string());
                    JSONArray data = json.getJSONObject("data").getJSONArray("activities");

                    for (int i = 0; i < data.length(); i++) {
                        final JSONObject item = data.getJSONObject(i);
                        final TextView textView = new TextView(this);
                        textView.setPadding(0, 0, 0, 20);

                        final String displayText = String.format("%s (%s) - %s steps - %s calories - %s km distance - %s heart rate - %s mins",
                                item.getString("activityName"),
                                item.getString("startTime"),
                                item.optInt("steps", 0),
                                item.getInt("calories"),
                                Math.round(item.optDouble("distance", 0)),
                                item.getInt("averageHeartRate"),
                                item.getInt("duration") / 60000);

                        textView.setText(displayText);
                        textView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

                        runOnUiThread(() -> recentContainer.addView(textView));
                    }
                }
            } catch (IOException | JSONException e) {
                e.printStackTrace();
            }
        });
    }

    public void loadWeeklyStats(final TextView view, final String type) {
        LocalDate endDate = LocalDate.now();
        LocalDate startDate = endDate.minusDays(7);

        final String urlStr = String.format("%sfitbit/activity/weekly?type=%s",
                BASE_URL,
                type,
                startDate.format(dateFormatter),
                endDate.format(dateFormatter));

        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try (Response response = httpClient.newCall(new Request.Builder().url(urlStr).build()).execute()) {
                if (response.code() == 200) {
                    double total = 0;
                    JSONArray data = new JSONObject(response.body().string())
                            .getJSONObject("data")
                            .getJSONArray(String.format("activities-%s", type));

                    for (int i = 0; i < data.length(); i++) {
                        JSONObject dayData = data.getJSONObject(i);
                        total += dayData.getDouble("value");
                    }

                    final String resultText = String.valueOf(Math.round(total));
                    runOnUiThread(() -> view.setText(resultText));
                } else {
                    //runOnUiThread(() -> componentManager.switchView("init"));
                }
            } catch (IOException | JSONException e) {
                e.printStackTrace();
            }
        });
    }

    public void loadDateRangeStats(final TextView view, final String type, LocalDate startDate, LocalDate endDate) {
        final String urlStr = String.format("%sfitbit/activity/range?type=%s&startDate=%s&endDate=%s",
                BASE_URL,
                type,
                startDate.format(dateFormatter),
                endDate.format(dateFormatter));

        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try (Response response = httpClient.newCall(new Request.Builder().url(urlStr).build()).execute()) {
                if (response.code() == 200) {
                    JSONObject json = new JSONObject(response.body().string());
                    final String resultText = String.valueOf(Math.round(
                            json.getJSONObject("data").getDouble("value")
                    ));
                    runOnUiThread(() -> view.setText(resultText));
                }
            } catch (IOException | JSONException e) {
                e.printStackTrace();
            }
        });
    }

    public void showDashboard(View view) {
        componentManager.switchView("dashboard");
    }

    public void backToInit(View view) {
        componentManager.switchView("init");
    }
}

 */