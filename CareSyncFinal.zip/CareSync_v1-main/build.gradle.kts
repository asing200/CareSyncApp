////// Top-level build file where you can add configuration options common to all sub-projects/modules.
////plugins {
////    alias(libs.plugins.android.application) apply false
////
////    id("com.android.application") // For app modules
////    id("kotlin-android")          // Include if using Kotlin
////}
////
////buildscript {
////    repositories {
////        google()
////        mavenCentral()
////    }
////    dependencies {
////        // Add Gradle Plugin dependencies here
////        classpath("com.android.tools.build:gradle:8.1.0")
////    }
////}
////
////android {
////    compileSdk = 33 // Ensure your compileSdk version is 24 or higher
////
////    defaultConfig {
////        applicationId = "edu.wit.caresync"
////        minSdk = 21 // Minimum version for desugaring
////        targetSdk = 33 // Match your compileSdk
////        multiDexEnabled = true // Required for multidexing if your app exceeds the 64K method limit
////    }
////
////    compileOptions {
////        // Enable Java 8 features and support for new APIs
////        sourceCompatibility = JavaVersion.VERSION_1_8
////        targetCompatibility = JavaVersion.VERSION_1_8
////        isCoreLibraryDesugaringEnabled = true // For AGP 4.1 and above
////    }
////}
////
////dependencies {
////    // Add the desugaring library dependency
////    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.3")
////}
//

plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "edu.wit.caresync"
    compileSdk = 34

    sourceSets["main"].manifest.srcFile("src/main/AndroidManifest.xml")


    defaultConfig {
        applicationId = "edu.wit.caresync"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
//        sourceCompatibility = JavaVersion.VERSION_11
//        targetCompatibility = JavaVersion.VERSION_11

        // Sets Java compatibility to Java 8
         sourceCompatibility = JavaVersion.VERSION_1_8
         targetCompatibility = JavaVersion.VERSION_1_8
    }
}

dependencies {
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
    implementation(libs.okhttp)
}